# 📦 GOOGLE PLAY STORE LISTING KIT - AKHAFIN

Gunakan teks dan materi di bawah ini saat mengisi form **Store Listing (Daftar Toko)** di Google Play Console.

---

### 1. Informasi Utama Aplikasi
* **Nama Aplikasi (App Title):** `AKHAFIN: Catat Keuangan & Kas` *(Maks 30 karakter)*
* **Deskripsi Singkat (Short Description):**  
  `Pencatat keuangan, arus kas (cashflow) & sisa saldo multi-bank & e-wallet.` *(Maks 80 karakter)*
* **Kategori Aplikasi:** `Keuangan (Finance)`
* **Tag Aplikasi:** `Keuangan Pribadi`, `Manajemen Uang`, `Pencatat Pengeluaran`, `Arus Kas`, `Dompet Digital`

---

### 2. Deskripsi Lengkap (Full Description) *(Maks 4000 karakter)*

```text
Kelola uang dengan lebih cerdas, rapi, dan terencana bersama AKHAFIN!

AKHAFIN (Akuntansi & Keuangan Finansial) adalah aplikasi modern all-in-one yang dirancang untuk membantu Anda memonitor arus kas (cashflow), mengontrol sisa saldo riil, serta melacak total saldo terkonsolidasi dari seluruh rekening bank dan dompet digital (e-wallet) Anda dalam satu tempat.

🌟 FITUR UTAMA AKHAFIN:

1. TOTAL SALDO TERKONSOLIDASI (MULTI-WALLET)
• Lihat total saldo bersih gabungan dari seluruh rekening bank, dompet digital, dan kas tunai secara real-time.
• Mendukung Bank BCA, Mandiri, BRI, BNI, Bank Jago, SeaBank, Jenius, BSI, CIMB Niaga, Blu by BCA, dll.
• Mendukung E-Wallet GoPay, OVO, DANA, ShopeePay, LinkAja, serta dompet tunai fisik.

2. PENCATATAN ARUS KAS (CASHFLOW TRACKING)
• 🟢 Pemasukan: Catat gaji, komisi, hasil bisnis, freelance, dividen, dan bonus.
• 🔴 Pengeluaran: Catat belanja harian, makanan/minuman, tagihan listrik & internet, transportasi, dan hiburan.
• 🔵 Transfer Antar Akun: Otomatis mendebit rekening asal dan mengkredit e-wallet tujuan (misal: Top-Up GoPay dari BCA) dilengkapi pencatatan biaya admin.

3. GRAFIK INTERAKTIF & ANALISIS CERDAS
• Grafik Arus Kas 6 Bulan: Pantau apakah kondisi finansial Anda sedang Surplus atau Defisit.
• Donut Chart Pengeluaran: Ketahui ke mana uang Anda paling banyak dibelanjakan per kategori.
• Perhitungan otomatis Rasio Tabungan (Savings Rate) dan daftar 5 pengeluaran terbesar.

4. 100% AMAN & PRIVAT (LOCAL STORAGE)
• Data keuangan Anda tersimpan langsung di memori perangkat Anda. Kami tidak menjual atau membagikan data transaksi Anda ke pihak ketiga.
• Cadangkan data (Backup JSON) dan pulihkan kapan saja.
• Ekspor riwayat transaksi ke format spreadsheet Microsoft Excel (.CSV) atau cetak langsung ke PDF.

👑 FITUR PREMIUM AKHAFIN PRO (BERLANGGANAN):
• Unlimited Rekening & E-Wallet tanpa batas.
• Fitur Anggaran & Budgeting Bulanan (Peringatan real-time jika pengeluaran mendekati batas).
• Ekspor Laporan Excel/CSV & Cetak PDF tanpa batasan.
• Proteksi Kunci Keamanan PIN & Biometrik (Sidik Jari / Face Unlock).
• Bebas Iklan & Akses Prioritas Fitur Baru.

Pilihan Paket Berlangganan Fleksibel:
• Paket Bulanan (Monthly)
• Paket Tahunan (Annual) - Paling Hemat 35%
• Paket Seumur Hidup (Lifetime VIP) - Sekali bayar selamanya

Unduh AKHAFIN sekarang dan wujudkan kebebasan finansial Anda dengan pencatatan keuangan yang rapi dan terukur!
```

---

### 3. Aset Grafis (Telah Dibuat di Folder Proyek)
1. **Ikon Aplikasi Resolusi Tinggi (App Icon):**
   * Lokasi: `c:\AppC\icon-512.png` *(512 x 512 px, format PNG 32-bit)*
2. **Gambar Fitur Utama (Feature Graphic Banner):**
   * Lokasi: `c:\AppC\feature-graphic.png` *(1024 x 500 px, format PNG)*
3. **URL Kebijakan Privasi (Privacy Policy URL):**
   * `https://[domain-anda]/kebijakan-privasi.html` (Wajib diisi di Play Console)

---

### 4. Data Safety (Keamanan Data) Form Answers
Saat mengisi kuesioner Data Safety di Google Play Console:
* **Apakah aplikasi mengumpulkan atau membagikan data pengguna?**
  * Pilih: **TIDAK (No)** untuk data transaksi keuangan, karena semua catatan mutasi disimpan di penyimpanan lokal perangkat pengguna (*On-device storage*).
* **Data Pembelian (Purchases):**
  * Google Play Billing mengelola data pembayaran secara otomatis.
* **Apakah data dienkripsi saat transit?**
  * Pilih: **YA (Yes)** (Semua komunikasi HTTPS).
