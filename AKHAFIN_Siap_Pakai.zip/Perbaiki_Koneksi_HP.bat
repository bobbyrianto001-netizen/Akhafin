@echo off
title AKHAFIN - Perbaikan & Peluncur Server HP
cd /d "%~dp0"

echo =====================================================================
echo          AKHAFIN - PERBAIKAN KONEKSI & SERVER HP / TABLET
echo =====================================================================
echo.
echo [1/2] Membuka izin Windows Firewall untuk Port 8080...
netsh advfirewall firewall delete rule name="AKHAFIN Web Server" >nul 2>&1
netsh advfirewall firewall add rule name="AKHAFIN Web Server" dir=in action=allow protocol=TCP localport=8080 >nul 2>&1
echo       Izin Firewall berhasil dikonfigurasi!
echo.
echo [2/2] Memeriksa alamat IP lokal dan menjalankan server...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0server.ps1"
pause
