@echo off
title AKHAFIN - Server Koneksi HP & Tablet
cd /d "%~dp0"

:: Buka izin firewall otomatis
netsh advfirewall firewall add rule name="AKHAFIN Web Server" dir=in action=allow protocol=TCP localport=8080 >nul 2>&1

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0server.ps1"
pause
