# 🚀 PANDUAN LENGKAP: UPLOAD APLIKASI AKHAFIN KE GOOGLE PLAY STORE & AKTIVASI SISTEM BERLANGGANAN

Panduan ini memandu Anda langkah demi langkah mulai dari membuat file rilis **Android App Bundle (.aab)**, menyiapkan akun Google Play Console, hingga mengonfigurasi **Sistem Berlangganan (Google Play Billing Subscriptions)**.

---

## 📑 DAFTAR ISI
1. [Syarat Awal Akun Google Play Console](#1-syarat-awal)
2. [Cara Menghasilkan File .AAB (Android App Bundle)](#2-cara-membuat-file-aab)
3. [Membuat Aplikasi Baru di Google Play Console](#3-membuat-aplikasi-baru)
4. [Mengatur Sistem Berlangganan (Subscriptions)](#4-mengatur-sistem-berlangganan)
5. [Mengisi Kebijakan Privasi & Data Safety](#5-kebijakan-privasi--data-safety)
6. [Upload File .AAB & Rilis ke Publik](#6-upload-dan-rilis)

---

## 1. Syarat Awal
Untuk mempublikasikan aplikasi ke Google Play Store, Anda memerlukan:
1. **Akun Google Play Console Developer:**
   * Buka: [play.google.com/console/signup](https://play.google.com/console/signup)
   * Biaya pendaftaran: **\$25 USD** (sekali bayar seumur hidup).
2. **Akun Merchant Google Payments:**
   * Wajib diaktifkan di dalam Play Console agar Anda dapat menerima pembayaran uang langganan dari pengguna ke rekening bank lokal Anda di Indonesia.
3. **Aset Grafis yang Sudah Siap di Folder Komputer Anda:**
   * Ikon 512x512: `c:\AppC\icon-512.png`
   * Banner Grafis 1024x500: `c:\AppC\feature-graphic.png`
   * Dokumen Kebijakan Privasi: `c:\AppC\kebijakan-privasi.html`

---

## 2. Cara Membuat File .AAB (Android App Bundle)

Anda dapat membuat file `.aab` menggunakan salah satu dari 2 cara di bawah ini:

### 🌟 CARA A (Paling Cepat & Otomatis - Menggunakan PWABuilder):
PWABuilder adalah alat resmi yang didukung Microsoft & Google untuk mengubah PWA menjadi file Google Play Store `.aab` siap upload:
1. Pastikan web aplikasi AKHAFIN Anda sudah ter-upload online (misal di Netlify: `https://akhafin.netlify.app`).
2. Buka situs: **[www.pwabuilder.com](https://www.pwabuilder.com)**.
3. Masukkan URL web AKHAFIN Anda, lalu klik **Start**.
4. Klik tombol **Package for Stores** ➔ pilih **Android**.
5. Masukkan rincian:
   * **Package ID:** `com.akhafin.app`
   * **App Name:** `AKHAFIN`
6. Klik **Generate** ➔ Unduh file zip yang berisi file **`app-release.aab`** dan kunci keystore. File `.aab` ini langsung siap diunggah ke Google Play Console!

### 💻 CARA B (Menggunakan Android Studio):
1. Buka software **Android Studio**.
2. Pilih **Open an Existing Project**, lalu arahkan ke folder:
   ```
   c:\AppC\android\
   ```
3. Tunggu proses *Gradle Sync* selesai.
4. Klik menu atas: **Build ➔ Generate Signed Bundle / APK...**
5. Pilih **Android App Bundle (.aab)** ➔ klik **Next**.
6. Masukkan Keystore (atau buat baru dengan klik *Create new...*).
7. Pilih Build Variant: **Release** ➔ klik **Finish**.
8. File `.aab` siap pakai akan terbentuk di folder `android/app/release/app-release.aab`.

---

## 3. Membuat Aplikasi Baru di Google Play Console

1. Masuk ke [Google Play Console](https://play.google.com/console).
2. Di pojok kanan atas, klik tombol **Buat Aplikasi (*Create App*)**.
3. Isi data dasar:
   * **Nama Aplikasi:** `AKHAFIN: Catat Keuangan & Kas`
   * **Bahasa Default:** Bahasa Indonesia (id)
   * **Jenis Aplikasi:** Aplikasi (App)
   * **Gratis atau Berbayar:** Gratis *(karena model monetisasi menggunakan langganan di dalam aplikasi / in-app subscriptions)*.
4. Centang persetujuan kebijakan developer Google Play ➔ klik **Buat Aplikasi**.

---

## 4. Mengatur Sistem Berlangganan (In-App Subscriptions)

Agar pengguna dapat berlangganan AKHAFIN PRO dan uangnya masuk ke rekening Anda:

1. Di menu navigasi samping Play Console, gulir ke bagian **Monetisasi (*Monetize*)** ➔ klik **Produk (*Products*)** ➔ pilih **Langganan (*Subscriptions*)**.
2. Klik **Buat Langganan (*Create subscription*)**.

### Buat 3 Paket Produk Berikut:

#### Paket 1: Langganan Bulanan
* **ID Produk:** `akhafin_pro_monthly`
* **Nama:** `AKHAFIN PRO Bulanan`
* **Deskripsi:** Akses penuh seluruh rekening tanpa batas, budgeting, dan proteksi biometrik.
* Klik **Tambahkan Paket Dasar (*Add base plan*)**:
  * Jenis: Perpanjangan Otomatis (*Auto-renewing*)
  * Periode Tagihan: 1 Bulan
  * Harga Indonesia: **Rp 19.000**
  * Klik **Aktifkan (*Activate*)**.

#### Paket 2: Langganan Tahunan (Paling Populer)
* **ID Produk:** `akhafin_pro_yearly`
* **Nama:** `AKHAFIN PRO Tahunan`
* **Deskripsi:** Hemat 35% untuk akses VIP tahunan.
* Tambahkan Paket Dasar:
  * Periode Tagihan: 1 Tahun
  * Harga Indonesia: **Rp 149.000**
  * Klik **Aktifkan**.

#### Paket 3: Pembelian Dalam Aplikasi (In-App Purchase - Seumur Hidup)
* Masuk ke menu **Produk Dalam Aplikasi (*In-app products*)** ➔ **Buat Produk**:
  * **ID Produk:** `akhafin_pro_lifetime`
  * **Nama:** `AKHAFIN PRO Seumur Hidup (VIP)`
  * **Harga:** **Rp 299.000**
  * Klik **Aktifkan**.

---

## 5. Mengisi Kebijakan Privasi & Data Safety

Google Play mewajibkan pengisian bagian ini sebelum aplikasi dapat disetujui:

1. Di menu samping Play Console, klik **Kebijakan & Program (*Policy & Programs*)** ➔ **Konten Aplikasi (*App Content*)**.
2. **Kebijakan Privasi (*Privacy Policy*):**
   * Masukkan tautan URL file kebijakan privasi Anda yang sudah di-hosting online:  
     Contoh: `https://[domain-anda]/kebijakan-privasi.html`
3. **Keamanan Data (*Data Safety*):**
   * Pertanyaan: *"Apakah aplikasi Anda mengumpulkan atau membagikan salah satu tipe data pengguna?"*
   * Jawab: **Tidak (No)** untuk data transaksi keuangan (karena data disimpan di perangkat lokal pengguna / *On-device storage*).
   * Bagian pembayaran ditangani secara otomatis oleh Google Play Billing.
4. **Target Audiens & Konten:**
   * Pilih usia: **18 tahun ke atas** atau semua umur (kategori Keuangan).
   * Aplikasi tidak ditargetkan khusus untuk anak-anak.

---

## 6. Upload File .AAB & Rilis ke Publik

1. Di menu navigasi samping, buka **Rilis (*Release*)** ➔ **Produksi (*Production*)**.
2. Klik **Buat Rilis Baru (*Create new release*)**.
3. Di bagian **App Bundle**, unggah file **`app-release.aab`** Anda.
4. Tulis catatan rilis (*Release notes*), contoh:
   ```text
   Rilis perdana aplikasi AKHAFIN v1.0.0.
   - Pencatat keuangan multi-bank & e-wallet
   - Fitur pelacakan arus kas (cashflow)
   - Dukungan langganan AKHAFIN PRO
   ```
5. Klik **Simpan (*Save*)** ➔ klik **Tinjau Rilis (*Review release*)** ➔ klik **Mulai Peluncuran ke Produksi (*Start rollout to Production*)**.

---

### ⏱️ Berapa Lama Proses Review Google Play?
* Peninjauan aplikasi baru oleh tim Google Play biasanya membutuhkan waktu **1 hingga 3 hari kerja**.
* Setelah disetujui (*Approved*), aplikasi AKHAFIN akan langsung aktif di Google Play Store dan dapat diunduh oleh jutaan pengguna di seluruh dunia!
